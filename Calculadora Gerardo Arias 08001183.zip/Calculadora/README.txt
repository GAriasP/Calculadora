GIT hub link:

https://github.com/GAriasP/Actividad-1-Programacion-avanzada-Gerardo-Arias.git